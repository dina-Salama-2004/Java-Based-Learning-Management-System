package com.LMS.User.Management.Models;

import lombok.Data;

@Data  // for setter and getter
public class User {
    private Integer id;
    private String name;
    private String password; // Password will be stored as a hashed value.
    private Role role; // User's role in the system.
    private String email;
    public User() {
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public User(String username, String password, Role role, String firstName, String lastName, String email) {
        this.name = username;
        this.password = password;
        this.role = role;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public Integer getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public Role getRole() {
        return role;
    }

    public String getEmail() {
        return email;
    }
}

