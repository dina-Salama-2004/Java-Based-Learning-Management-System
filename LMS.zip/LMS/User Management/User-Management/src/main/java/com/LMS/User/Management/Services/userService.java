package com.LMS.User.Management.Services;


import com.LMS.User.Management.Models.Profile;
import com.LMS.User.Management.Models.User;
import com.LMS.User.Management.Models.loginData;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;


import java.util.*;

import java.util.concurrent.atomic.AtomicInteger;

@Service
public class userService
{


    private List<User> usersList = new ArrayList<>();


    @PostMapping("/register")
    public ResponseEntity<Object> register(@RequestBody User user) {

        // Validate input fields
        if (user.getName() == null || user.getName().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Name is required.");
        }
        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Password is required.");
        }
        if (user.getRole() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Role is required.");
        }
        if (user.getId() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("ID is required.");
        }

        // Check if user ID already exists
        boolean userIdExists = usersList.stream()
                .anyMatch(u -> {
                    return Objects.equals(u.getId(), user.getId());
                });


        if (userIdExists) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("ID = " + user.getId() + " is already used. Please choose a new ID.");
        }


        boolean userNameMailExists = usersList.stream()
                .anyMatch(u ->
                        Objects.equals(u.getName(), user.getName()) &&
                                Objects.equals(u.getEmail(), user.getEmail())
                );
if (userNameMailExists) {

    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(" name : ' " + user.getName() + " ' is already used with the email " + user.getEmail() + ". Please choose a new name or Email  or both .") ;
}


        usersList.add(user);
//add profile

        Profile profile = new Profile(user);
        profiles.add(profile);

        return ResponseEntity.status(HttpStatus.CREATED).body(user);
    }





    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody loginData loginData) {

        boolean userExists = usersList.stream()
                .anyMatch(u -> u.getName().equals(loginData.getUsername()) && u.getPassword().equals(loginData.getPassword()));

        if (userExists) {
            return ResponseEntity.ok("Login successful!");
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body("Login failed! You should first register or enter your password and username correctly.");
    }




    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        if (usersList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }
        return ResponseEntity.ok(usersList);
    }

// profile

    private List<Profile> profiles = new ArrayList<>();

    @PostMapping("/editprofile")
    public ResponseEntity<Object> editProfile(@RequestBody Profile userProfile) {
        try {

           // based on user id

            Profile existingProfile = null;
            for (Profile p : profiles) {
                if (p.getUser().getId().equals(userProfile.getUser().getId())) {
                    existingProfile = p;
                    break;
                }
            }

            if (existingProfile != null)
            {

                boolean isNameChanged = !userProfile.getUser().getName().equals(existingProfile.getUser().getName());
                boolean isEmailChanged = !userProfile.getUser().getEmail().equals(existingProfile.getUser().getEmail());

                if (isNameChanged && isEmailChanged) {
                    // Check if the new name/email combination already exists in the system
                    if (profiles.stream().anyMatch(p ->
                            p.getUser().getName().equals(userProfile.getUser().getName()) &&
                                    p.getUser().getEmail().equals(userProfile.getUser().getEmail()))) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body("The name '" + userProfile.getUser().getName() + "' is already taken with the  same email '" + userProfile.getUser().getEmail() + "'. Please choose a different name or email.");
                    }
                    else
                    {

                        existingProfile.setUser(userProfile.getUser());
                    }
                }

                existingProfile.setUser(userProfile.getUser());
                existingProfile.setAddress(userProfile.getAddress());
                existingProfile.setPhoneNumber(userProfile.getPhoneNumber());

                return ResponseEntity.ok(existingProfile); // Return updated profile
            }

            else if (existingProfile != null)
            {
                return ResponseEntity.status(404).body("you cant change id  ! , your  id must remain " + userProfile.getUser().getId() );
            }
            else {
                return ResponseEntity.status(404).body("profile is empty , not exist "  );
            }
        } catch (Exception e) {
            // Handle any unexpected errors
            return ResponseEntity.status(500).body("Error updating profile: " + e.getMessage());
        }
    }



    //
    @GetMapping("/viewprofile")
    public ResponseEntity<Object> getProfile(@RequestParam("userid") Integer id) {
        // Search for the profile by user ID
        for (Profile p : profiles) {
            if (p.getUser().getId().equals(id)) {
                return ResponseEntity.ok(p); // Return the profile if found
            }
        }

        // Return a 404 response with an error message in a structured format
        Map<String, String> errorResponse = new HashMap<>();
        errorResponse.put("error", "No user profile found for ID: " + id +" .");

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }


    @GetMapping("/profiles")
    public ResponseEntity<List<Profile>> getAllProfiles()
    {
        if (profiles.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }
        return ResponseEntity.ok(profiles);
    }
};