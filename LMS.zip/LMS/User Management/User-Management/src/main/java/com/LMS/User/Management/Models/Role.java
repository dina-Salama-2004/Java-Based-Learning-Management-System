package com.LMS.User.Management.Models;


public enum Role {
    ADMIN,
    INSTRUCTOR,
    STUDENT
}