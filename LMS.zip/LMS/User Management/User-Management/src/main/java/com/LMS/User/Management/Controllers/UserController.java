package com.LMS.User.Management.Controllers;

import com.LMS.User.Management.Models.Profile;
import com.LMS.User.Management.Models.User;
import com.LMS.User.Management.Models.loginData;

import com.LMS.User.Management.Services.userService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("User")
public class UserController
{

    userService userService=new userService();

//Features




    // 1- UserRegistration  and   Login


    @PostMapping("/register")
    public ResponseEntity<Object> register(@RequestBody User user)
    {

        return ResponseEntity.ok(userService.register(user)).getBody();
    }

    @PostMapping("/login")
    public ResponseEntity<String>  login(@RequestBody loginData user)
    {

        return ResponseEntity.ok(userService.login(user)).getBody();
    }



    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return userService.getAllUsers();
    }



//   2- Profile Management (view/update profile information).



@PostMapping("/editprofile")
public ResponseEntity<Object> editProfile(@RequestBody Profile userProfile){

        return ResponseEntity.ok(userService.editProfile(userProfile));
}



    @GetMapping("/viewprofile")
    public ResponseEntity<Object> getProfile( @RequestParam("userid") Integer id) {
        return userService.getProfile(id);
    }

    @GetMapping("/profiles")
    public ResponseEntity<List<Profile>> getAllProfiles() {
        return userService.getAllProfiles();
    }


}